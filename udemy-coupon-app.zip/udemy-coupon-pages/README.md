# Free Udemy Coupon Site — Setup Guide (No Coding Needed)

This runs entirely for free using GitHub: GitHub Actions automatically scrapes
and verifies coupons on a schedule, and GitHub Pages hosts the website. You
don't need to install anything on your computer or run any servers.

## Step 1 — Create a GitHub account
Go to https://github.com/join and sign up (free).

## Step 2 — Create a new repository
1. Click the **+** icon (top right) → **New repository**.
2. Name it something like `udemy-coupons`.
3. Set it to **Public** (required for free GitHub Pages + Actions).
4. Click **Create repository**.

## Step 3 — Upload these files
1. On your new repository's page, click **Add file → Upload files**.
2. Drag the entire downloaded project folder (with all its subfolders:
   `.github`, `docs`, `scripts`, and `package.json`) into the upload box.
   Most browsers let you drag a whole folder in at once — if it doesn't
   accept folders, use **GitHub Desktop** (https://desktop.github.com)
   instead, which lets you drag the folder in and click "Publish."
3. Scroll down and click **Commit changes**.

Double check afterward that the repository contains these at the top level:
`.github/workflows/update.yml`, `docs/index.html`, `docs/data/coupons.json`,
`scripts/scrape-reddit.js`, `scripts/check-coupons.js`, `scripts/lib/store.js`,
`package.json`.

## Step 4 — Allow the automation to save its results
1. Go to your repo's **Settings** tab.
2. In the left sidebar, click **Actions → General**.
3. Scroll to **Workflow permissions**.
4. Select **Read and write permissions**.
5. Click **Save**.

(This lets the scheduled job update `coupons.json` with new results.)

## Step 5 — Turn on the website (GitHub Pages)
1. Still in **Settings**, click **Pages** in the left sidebar.
2. Under **Build and deployment → Source**, choose **Deploy from a branch**.
3. Under **Branch**, select `main` and folder `/docs`, then click **Save**.
4. Wait about a minute, then refresh — GitHub will show you your site's
   address, something like `https://yourusername.github.io/udemy-coupons/`.

## Step 6 — Run the collector for the first time
1. Click the **Actions** tab at the top of the repo.
2. You'll see a workflow called **Update Coupons** — click it.
3. Click **Run workflow** (button on the right) → **Run workflow** again to
   confirm.
4. Wait 2–5 minutes for it to finish (you can click into the run to watch
   the progress live).
5. Once it's done, visit your site URL from Step 5 — you should see any
   verified free courses it found.

After this, it repeats automatically every 3 hours — you don't need to do
anything further. You can change how often by editing the `cron` line in
`.github/workflows/update.yml` (e.g. `0 */6 * * *` for every 6 hours).

## If the site shows nothing
This usually just means no currently-listed Reddit posts contained a working
100%-off coupon at that moment — that's expected sometimes, since these
codes expire fast and supply varies day to day. Check the **Actions** tab to
confirm the workflow ran successfully (green checkmark); click into a run
and expand the log steps to see what it found/checked.

## Limitations to know about
- **Coverage**: it only checks a handful of Reddit communities right now.
  More sources (Telegram, other coupon sites, an instructor submission form)
  can be added later, but that's a coding task.
- **Reddit may eventually rate-limit it**: if scraping consistently returns
  zero results, Reddit's public feed may be throttling GitHub's IP ranges.
  The fix is registering a free Reddit API app, which is a code change.
- **Udemy may change their page design**, which could break the
  free/not-free price detection. If the site stops finding any active
  coupons at all even though Reddit posts exist, this is the likely cause.
- This is a personal/hobby-scale tool, not a production-grade service —
  it's meant to get you a working free site at zero cost, not to compete
  with major coupon aggregators.
